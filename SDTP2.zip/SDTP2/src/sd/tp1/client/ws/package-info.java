@javax.xml.bind.annotation.XmlSchema(namespace = "http://server.tp1.sd/")
package sd.tp1.client.ws;
